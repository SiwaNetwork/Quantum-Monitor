## This is a termnial based GUI (ncurses) to configure the Time Card ##

Please note: this script is under construction and is not functional at the moment!
